# vectaetos_lsp.py
# Python 3.11+
# VECTAETOS_ROLE: utility
"""
VECTAETOS Code Sentinel LSP — research prototype.

This file is a local editor sentinel, not a validator.

It is NOT:
- a truth validator
- a deployment validator
- an optimizer
- a decision engine
- a canonical guard
- an authority over Φ, K(Φ), κ, QE, Vortex, Projection, EK, or human judgment

It only exposes possible semantic drift for human review.

Main design corrections:
- role inference is explicit-first: file header > contract path rules > utility
- filename substring heuristics are disabled by default
- rules are loaded from contracts/vectaetos_code_contract.json when present
- embedded rules are fallback only
- ledger writes are explicit only, never automatic from diagnostics
"""

from __future__ import annotations

import ast
import fnmatch
import hashlib
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
from urllib.parse import unquote, urlparse

import jedi
from lsprotocol.types import (
    CompletionItem,
    CompletionList,
    CompletionParams,
    Diagnostic,
    DiagnosticSeverity,
    DidOpenTextDocumentParams,
    DidSaveTextDocumentParams,
    Position,
    Range,
)
from pygls.features import COMPLETION, TEXT_DOCUMENT_DID_OPEN, TEXT_DOCUMENT_DID_SAVE
from pygls.server import LanguageServer

CONTRACT_PATH = Path("contracts/vectaetos_code_contract.json")
LEDGER_PATH = Path(".vectaetos/ledger.log")
MAX_WORKERS = 2

DEFAULT_CONTRACT: Dict[str, Any] = {
    "version": "0.1.0",
    "status": "research",
    "role_header": {
        "key": "VECTAETOS_ROLE",
        "required": False,
        "allowed_roles": [
            "vortex",
            "projection",
            "adapter",
            "audit",
            "guard",
            "test",
            "utility",
            "research",
        ],
        "missing_role_severity": "hint",
    },
    "heuristic_role_inference": False,
    "role_path_patterns": {
        "vortex": ["vortex/**/*.py"],
        "projection": ["projection/**/*.py", "glyph/**/*.py"],
        "adapter": ["adapters/**/*.py", "llm/**/*.py"],
        "audit": ["audit/**/*.py"],
        "guard": ["guards/**/*.py"],
        "test": ["tests/**/*.py"],
        "research": ["research/**/*.py"],
    },
    "protected_ontology_names": [
        "PHI",
        "Phi",
        "K",
        "K_PHI",
        "KPhi",
        "KAPPA",
        "kappa",
        "QE",
    ],
    "restricted_mutation_roles": ["vortex", "projection", "adapter"],
    "forbidden_fragments": [
        "decide",
        "decision",
        "recommend",
        "optimize",
        "reward",
        "policy_update",
        "best_trajectory",
        "select_best",
        "rank",
        "argmax",
        "argmin",
    ],
    "dynamic_execution_calls": ["eval", "exec", "compile", "__import__"],
    "severity": {
        "forbidden_fragment": "warning",
        "protected_assignment": "error",
        "dynamic_execution": "error",
        "invalid_role_header": "warning",
        "missing_role_header": "hint",
    },
}

server = LanguageServer("vectaetos-code-sentinel-lsp", "0.4.0")
executor = ThreadPoolExecutor(max_workers=MAX_WORKERS)


def deep_merge(base: Dict[str, Any], override: Mapping[str, Any]) -> Dict[str, Any]:
    """Return base recursively merged with override."""
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, Mapping) and isinstance(result.get(key), Mapping):
            result[key] = deep_merge(dict(result[key]), value)
        else:
            result[key] = value
    return result


def load_contract(path: Path = CONTRACT_PATH) -> Dict[str, Any]:
    """
    Load external contract. If it is missing or invalid, fall back to defaults.

    The contract configures role headers, path mappings, protected names,
    forbidden fragments, and severity levels.
    """
    if not path.exists():
        return dict(DEFAULT_CONTRACT)
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(loaded, dict):
            return dict(DEFAULT_CONTRACT)
        return deep_merge(dict(DEFAULT_CONTRACT), loaded)
    except Exception:
        return dict(DEFAULT_CONTRACT)


CONTRACT = load_contract()


def severity_from_name(name: str, default: DiagnosticSeverity) -> DiagnosticSeverity:
    mapping = {
        "error": DiagnosticSeverity.Error,
        "warning": DiagnosticSeverity.Warning,
        "information": DiagnosticSeverity.Information,
        "info": DiagnosticSeverity.Information,
        "hint": DiagnosticSeverity.Hint,
    }
    return mapping.get(str(name).lower(), default)


def contract_severity(key: str, default: DiagnosticSeverity) -> DiagnosticSeverity:
    severity_cfg = CONTRACT.get("severity", {})
    if not isinstance(severity_cfg, dict):
        return default
    return severity_from_name(str(severity_cfg.get(key, "")), default)


def deterministic_serialize(obj: Any) -> bytes:
    """Serialize objects with sorted keys and stable float formatting."""
    def _clean(value: Any) -> Any:
        if isinstance(value, dict):
            return {key: _clean(value[key]) for key in sorted(value)}
        if isinstance(value, (list, tuple)):
            return [_clean(item) for item in value]
        if isinstance(value, float):
            return format(value, ".12g")
        return value

    text = json.dumps(_clean(obj), separators=(",", ":"), ensure_ascii=False)
    return text.encode("utf-8")


def dual_hash(data: bytes) -> Tuple[str, str]:
    """Return SHA-256 and SHA3-512 hex fingerprints."""
    return hashlib.sha256(data).hexdigest(), hashlib.sha3_512(data).hexdigest()


class Ledger:
    """
    Append-only audit ledger.

    It is passive and explicit only.
    Diagnostics must never write ledger records automatically.
    """

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def commit(self, meta: Dict[str, Any]) -> Dict[str, str]:
        """
        Commit an explicit audit trace.

        The timestamp makes the event time-bound.
        Deterministic serialization applies to payload shape, not to replay identity.
        """
        payload = {"meta": meta, "ts": time.time()}
        data = deterministic_serialize(payload)
        sha256, sha3 = dual_hash(data)

        record = {
            "ts": payload["ts"],
            "sha256": sha256,
            "sha3": sha3,
            "meta": meta,
        }

        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, separators=(",", ":"), ensure_ascii=False) + "\n")

        return {"sha256": sha256, "sha3": sha3}


ledger = Ledger(LEDGER_PATH)


def uri_to_path_string(uri: Optional[str]) -> str:
    """Convert LSP URI or path-like input into a normalized path string."""
    if not uri:
        return ""
    if uri.startswith("file://"):
        parsed = urlparse(uri)
        return unquote(parsed.path or uri)
    return uri


def relative_path_for_contract(uri: Optional[str]) -> str:
    """Return a POSIX-like relative path if possible."""
    path_text = uri_to_path_string(uri)
    if not path_text:
        return ""
    path = Path(path_text)
    try:
        rel = path.resolve().relative_to(Path.cwd().resolve())
        return rel.as_posix()
    except Exception:
        return path.as_posix()


def extract_role_header(source: str) -> Tuple[Optional[str], Optional[int]]:
    """
    Extract explicit role from first 40 lines.

    Accepted form:
    # VECTAETOS_ROLE: vortex
    """
    header_cfg = CONTRACT.get("role_header", {})
    key = "VECTAETOS_ROLE"
    if isinstance(header_cfg, dict):
        key = str(header_cfg.get("key", key))

    pattern = re.compile(
        rf"^\s*#\s*{re.escape(key)}\s*:\s*([A-Za-z0-9_\-]+)\s*$",
        re.IGNORECASE,
    )

    for index, line in enumerate(source.splitlines()[:40]):
        match = pattern.match(line)
        if match:
            return match.group(1).lower(), index

    return None, None


def allowed_roles() -> List[str]:
    header_cfg = CONTRACT.get("role_header", {})
    if isinstance(header_cfg, dict) and isinstance(header_cfg.get("allowed_roles"), list):
        return [str(role).lower() for role in header_cfg["allowed_roles"]]
    return list(DEFAULT_CONTRACT["role_header"]["allowed_roles"])


def role_from_contract_path(uri: Optional[str]) -> Optional[str]:
    """
    Resolve role from explicit path patterns in contract.

    This avoids fragile substring tests like "vortex" in filename.
    """
    rel = relative_path_for_contract(uri)
    if not rel:
        return None

    path_rules = CONTRACT.get("role_path_patterns", {})
    if not isinstance(path_rules, dict):
        return None

    for role, patterns in path_rules.items():
        if not isinstance(patterns, list):
            continue
        for pattern in patterns:
            if fnmatch.fnmatch(rel, str(pattern)):
                return str(role).lower()

    return None


def make_diag(
    node: ast.AST,
    message: str,
    severity: DiagnosticSeverity = DiagnosticSeverity.Error,
) -> Diagnostic:
    """Create a one-character LSP diagnostic at node location."""
    lineno = getattr(node, "lineno", 1) - 1
    col = getattr(node, "col_offset", 0)

    return Diagnostic(
        range=Range(
            start=Position(line=lineno, character=col),
            end=Position(line=lineno, character=col + 1),
        ),
        message=message,
        severity=severity,
        source="VectaetosCodeSentinel",
    )


def infer_role(uri: Optional[str], source: str) -> Tuple[str, List[Diagnostic]]:
    """
    Resolve role in explicit-first order:
    1. file header
    2. contract path patterns
    3. optional legacy heuristic if enabled
    4. utility
    """
    diagnostics: List[Diagnostic] = []
    role, line_index = extract_role_header(source)
    valid_roles = set(allowed_roles())

    if role is not None:
        if role not in valid_roles:
            dummy = ast.Pass()
            dummy.lineno = (line_index or 0) + 1
            dummy.col_offset = 0
            diagnostics.append(
                make_diag(
                    dummy,
                    f"INVALID_ROLE_HEADER: role '{role}' is not allowed by contract",
                    contract_severity("invalid_role_header", DiagnosticSeverity.Warning),
                )
            )
            return "utility", diagnostics
        return role, diagnostics

    header_cfg = CONTRACT.get("role_header", {})
    if isinstance(header_cfg, dict) and bool(header_cfg.get("required", False)):
        dummy = ast.Pass()
        dummy.lineno = 1
        dummy.col_offset = 0
        diagnostics.append(
            make_diag(
                dummy,
                "MISSING_ROLE_HEADER: add '# VECTAETOS_ROLE: <role>' or rely on explicit contract path rules",
                contract_severity("missing_role_header", DiagnosticSeverity.Hint),
            )
        )

    contract_role = role_from_contract_path(uri)
    if contract_role in valid_roles:
        return contract_role, diagnostics

    # Legacy heuristic is off by default. If enabled, it only checks directories.
    if bool(CONTRACT.get("heuristic_role_inference", False)):
        text = relative_path_for_contract(uri).lower()
        if "/vortex/" in text:
            return "vortex", diagnostics
        if "/projection/" in text or "/glyph/" in text:
            return "projection", diagnostics
        if "/adapters/" in text or "/llm/" in text:
            return "adapter", diagnostics
        if "/audit/" in text:
            return "audit", diagnostics
        if "/guards/" in text:
            return "guard", diagnostics
        if "/tests/" in text:
            return "test", diagnostics

    return "utility", diagnostics


def string_list(value: Any, fallback: Sequence[str]) -> List[str]:
    if isinstance(value, list):
        return [str(item) for item in value]
    return list(fallback)


def analyze_source(uri: str, source: str) -> List[Diagnostic]:
    """
    Analyze Python source for possible semantic drift.

    Diagnostics are advisory. They do not validate or invalidate code.
    """
    diagnostics: List[Diagnostic] = []

    role, role_diagnostics = infer_role(uri, source)
    diagnostics.extend(role_diagnostics)

    try:
        tree = ast.parse(source)
    except SyntaxError:
        return diagnostics

    protected_names = set(
        string_list(
            CONTRACT.get("protected_ontology_names"),
            DEFAULT_CONTRACT["protected_ontology_names"],
        )
    )
    restricted_roles = set(
        string_list(
            CONTRACT.get("restricted_mutation_roles"),
            DEFAULT_CONTRACT["restricted_mutation_roles"],
        )
    )
    forbidden_fragments = tuple(
        fragment.lower()
        for fragment in string_list(
            CONTRACT.get("forbidden_fragments"),
            DEFAULT_CONTRACT["forbidden_fragments"],
        )
    )
    dynamic_calls = set(
        string_list(
            CONTRACT.get("dynamic_execution_calls"),
            DEFAULT_CONTRACT["dynamic_execution_calls"],
        )
    )

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            name = getattr(node, "name", "")
            lower_name = name.lower()
            if any(fragment in lower_name for fragment in forbidden_fragments):
                diagnostics.append(
                    make_diag(
                        node,
                        f"ONTOLOGICAL_DRIFT: advisory fragment in definition name '{name}'",
                        contract_severity("forbidden_fragment", DiagnosticSeverity.Warning),
                    )
                )

        if isinstance(node, ast.Name):
            identifier = node.id
            lower_identifier = identifier.lower()
            if any(fragment in lower_identifier for fragment in forbidden_fragments):
                diagnostics.append(
                    make_diag(
                        node,
                        f"ONTOLOGICAL_DRIFT: advisory token '{identifier}'",
                        contract_severity("forbidden_fragment", DiagnosticSeverity.Warning),
                    )
                )

        if isinstance(node, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
            if isinstance(node, ast.Assign):
                targets: Iterable[ast.expr] = node.targets
            else:
                targets = [node.target]

            for target in targets:
                if isinstance(target, ast.Name):
                    if target.id in protected_names and role in restricted_roles:
                        diagnostics.append(
                            make_diag(
                                target,
                                f"PHI_MUTATION: assignment to protected ontology name '{target.id}' in role '{role}'",
                                contract_severity("protected_assignment", DiagnosticSeverity.Error),
                            )
                        )

        if isinstance(node, ast.Call):
            func = node.func
            call_name = ""

            if isinstance(func, ast.Name):
                call_name = func.id
            elif isinstance(func, ast.Attribute):
                call_name = func.attr

            if call_name in dynamic_calls:
                diagnostics.append(
                    make_diag(
                        node,
                        f"DYNAMIC_EXECUTION: forbidden call '{call_name}'",
                        contract_severity("dynamic_execution", DiagnosticSeverity.Error),
                    )
                )

    return diagnostics


@server.feature(TEXT_DOCUMENT_DID_OPEN)
async def did_open(ls: LanguageServer, params: DidOpenTextDocumentParams):
    """Analyze a document after open."""
    doc = ls.workspace.get_document(params.text_document.uri)
    ls.loop.run_in_executor(executor, _analyze_and_publish, ls, doc)


@server.feature(TEXT_DOCUMENT_DID_SAVE)
async def did_save(ls: LanguageServer, params: DidSaveTextDocumentParams):
    """Analyze a document after save."""
    doc = ls.workspace.get_document(params.text_document.uri)
    ls.loop.run_in_executor(executor, _analyze_and_publish, ls, doc)


def _analyze_and_publish(ls: LanguageServer, doc: Any) -> None:
    diagnostics = analyze_source(doc.uri, doc.source)
    ls.publish_diagnostics(doc.uri, diagnostics)


@server.feature(COMPLETION)
def completions(ls: LanguageServer, params: CompletionParams) -> CompletionList:
    """Provide completions via Jedi."""
    doc = ls.workspace.get_document(params.text_document.uri)
    line = params.position.line + 1
    column = params.position.character

    try:
        script = jedi.Script(code=doc.source, path=str(doc.path) if doc.path else None)
        completions_ = script.complete(line, column)
    except Exception:
        return CompletionList(is_incomplete=False, items=[])

    items: List[CompletionItem] = []
    for completion in completions_:
        items.append(
            CompletionItem(
                label=completion.name,
                detail=completion.type or "",
                documentation=completion.description,
            )
        )

    return CompletionList(is_incomplete=False, items=items)


def commit_trajectory_trace(meta: Dict[str, Any]) -> Dict[str, str]:
    """
    Explicitly commit a trajectory/audit trace.

    This must be called by a deliberate editor/user action.
    The LSP server does not call it automatically.
    """
    return ledger.commit(meta)


if __name__ == "__main__":
    server.start_io()
