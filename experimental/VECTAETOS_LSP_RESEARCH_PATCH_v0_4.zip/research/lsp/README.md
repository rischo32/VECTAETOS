# VECTAETOS Code Sentinel LSP

Status: **RESEARCH PROTOTYPE**

This folder contains a local Language Server Protocol sentinel for advisory editor diagnostics.

It is not a canonical guard.

It is not a validator.

It is not a deployment safety mechanism.

It does not define VECTAETOS truth.

It does not decide code validity.

It only exposes possible semantic drift for human review.

## Why this exists

The sentinel helps catch possible drift early while writing Python code.

It checks for:

- agentic or optimization fragments in names
- protected ontology assignment in restricted roles
- dynamic execution calls
- missing or invalid explicit role headers, if configured

## Role declaration

Prefer explicit role headers over filename guessing.

Add one of these near the top of a Python file:

```python
# VECTAETOS_ROLE: vortex
# VECTAETOS_ROLE: projection
# VECTAETOS_ROLE: adapter
# VECTAETOS_ROLE: audit
# VECTAETOS_ROLE: guard
# VECTAETOS_ROLE: test
# VECTAETOS_ROLE: utility
# VECTAETOS_ROLE: research
```

Role resolution order:

1. explicit file header
2. `contracts/vectaetos_code_contract.json` path patterns
3. optional legacy heuristics if enabled
4. `utility`

Filename substring heuristics are disabled by default.

This prevents fragile matches like `my_vortex_utils.py`.

## Contract

Expected config path:

```text
contracts/vectaetos_code_contract.json
```

The contract defines:

- allowed roles
- role path patterns
- protected ontology names
- forbidden fragments
- dynamic execution calls
- diagnostic severities

## Ledger

The ledger helper is opt-in only.

The LSP never writes ledger records automatically.

Ledger commits require an explicit call to:

```python
commit_trajectory_trace(meta)
```

Ledger records are audit fingerprints, not proof of truth.

## Non-authority rule

Warnings are not commands.

Errors are not truth.

Diagnostics are signals for human review.

Do not blindly edit code just to satisfy the LSP.
