#!/usr/bin/env python3
"""
VECTAETOS — Tiered AnchorLoader

Non-authoritative live anchor loader for LSP hover/context assistance.

Boundary:
    AnchorLoader ≠ truth source.
    Gravity ≠ authority.
    Hover ≠ verdict.
    Recency must not override canonical status, review status, path status,
    conflict precedence, or anchor precedence.

This module is read-only and path-bounded. It performs file I/O only during
initialization/reload, never per query.
"""

from __future__ import annotations

import hashlib
import math
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


TEXT_SUFFIXES = {".md", ".txt", ".rst"}
EXCLUDED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "__pycache__",
    ".venv",
    "venv",
    "env",
    "node_modules",
    "dist",
    "build",
    "archive",
    ".next",
    ".cache",
}

DEFAULT_MAX_FILE_BYTES = 2_000_000

ROLE_TIER = {
    "canonical": 50,
    "official": 50,
    "frozen_anchor": 50,
    "working_anchor": 40,
    "canonical_candidate": 40,
    "contract": 30,
    "machine_projection": 30,
    "reference": 20,
    "packaged_reference": 20,
    "draft": 10,
    "research": 10,
    "staging": 10,
    "experiment": 0,
    "playground": 0,
    "scratch": 0,
    "unknown": 0,
}


@dataclass(frozen=True)
class ContextItem:
    """A loaded anchor/reference fragment.

    `role` controls canonical tier. It is not inferred from gravity.
    """

    source: str
    heading: str
    text: str
    role: str
    modified_at: float
    importance: float = 0.5
    reliability: float = 0.5
    continuity: float = 0.5


@dataclass(frozen=True)
class RankedContextItem:
    item: ContextItem
    semantic_similarity: float
    gravity: float
    tier: int


def _clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def tokenize(text: str) -> set[str]:
    return {
        token.lower()
        for token in re.findall(r"[\wΦφκΣΞΔ]+", text, flags=re.UNICODE)
        if len(token) >= 2
    }


def semantic_similarity(term: str, text: str, heading: str = "") -> float:
    """Small deterministic lexical similarity fallback.

    LSPs may replace this with embeddings, but the ranking rule must remain:
    canonical_tier first, gravity second.
    """

    query_tokens = tokenize(term)
    if not query_tokens:
        return 0.0

    text_tokens = tokenize(f"{heading}\n{text}")
    if not text_tokens:
        return 0.0

    overlap = len(query_tokens & text_tokens) / len(query_tokens)

    heading_tokens = tokenize(heading)
    heading_boost = 0.15 if query_tokens & heading_tokens else 0.0

    literal_boost = 0.25 if term.lower() in f"{heading}\n{text}".lower() else 0.0

    return _clamp01(overlap + heading_boost + literal_boost)


def recency_signal(modified_at: float, *, now: float | None = None) -> float:
    """Ergonomic recency signal.

    This signal may only affect ordering inside the same canonical tier.
    It must never override canonical status or review status.
    """

    current_time = time.time() if now is None else now
    age_seconds = max(0.0, current_time - modified_at)
    return math.exp(-age_seconds / (30 * 86400))


def canonical_tier(item: ContextItem) -> int:
    """Return path/status tier before gravity.

    This is the key fix: canonical precedence is not a scalar bonus inside
    gravity. It is a separate ranking tier sorted before gravity.
    """

    return ROLE_TIER.get(item.role, ROLE_TIER["unknown"])


def gravity_score(
    item: ContextItem,
    semantic_sim: float,
    *,
    now: float | None = None,
) -> float:
    """Return ergonomic retrieval score inside the same canonical tier.

    Gravity is not truth, authority, safety, validity, or ontology.
    """

    recency = recency_signal(item.modified_at, now=now)

    return (
        0.50 * _clamp01(semantic_sim)
        + 0.20 * _clamp01(item.importance)
        + 0.10 * recency
        + 0.10 * _clamp01(item.reliability)
        + 0.10 * _clamp01(item.continuity)
    )


def ranking_key(ranked: RankedContextItem) -> tuple[int, float, float, str, str]:
    """Sort canonical tier before gravity.

    Recency is already folded into gravity, so it can only decide among items
    with equal/same canonical tier. It cannot lift experiments above canonical
    anchors.
    """

    return (
        ranked.tier,
        ranked.gravity,
        ranked.semantic_similarity,
        ranked.item.source,
        ranked.item.heading,
    )


def infer_role(path: Path, root: Path) -> str:
    """Infer non-authoritative role from path.

    Repository contracts may override this. This fallback must not become an
    ontology source.
    """

    rel_parts = path.resolve().relative_to(root.resolve()).parts
    first = rel_parts[0].lower() if rel_parts else ""

    name = path.name.lower()

    if first in {"anchors", "ontology", "formal"}:
        if "draft" in name or "candidate" in name:
            return "working_anchor"
        return "canonical"

    if first == "contracts":
        return "contract"

    if first in {"references", "docs"}:
        return "reference"

    if first in {"drafts", "research", "staging"}:
        return "draft"

    if first in {"experiments", "scratch", "playground", "notebooks", "examples"}:
        return "experiment"

    return "unknown"


def iter_text_files(
    root: Path,
    *,
    follow_symlinks: bool = False,
    max_file_bytes: int = DEFAULT_MAX_FILE_BYTES,
) -> Iterable[Path]:
    """Yield text files under root with directory pruning and symlink protection."""

    resolved_root = root.resolve(strict=True)

    for dirpath, dirnames, filenames in os.walk(resolved_root, followlinks=follow_symlinks):
        current = Path(dirpath)

        pruned: list[str] = []
        for dirname in sorted(dirnames):
            child = current / dirname
            if dirname in EXCLUDED_DIRS:
                continue
            if child.is_symlink() and not follow_symlinks:
                continue
            try:
                child_resolved = child.resolve(strict=False)
            except OSError:
                continue
            if not str(child_resolved).startswith(str(resolved_root)):
                continue
            pruned.append(dirname)

        dirnames[:] = pruned

        for filename in sorted(filenames):
            path = current / filename
            if path.suffix.lower() not in TEXT_SUFFIXES:
                continue
            if path.is_symlink() and not follow_symlinks:
                continue
            try:
                resolved_path = path.resolve(strict=True)
            except OSError:
                continue
            if not str(resolved_path).startswith(str(resolved_root)):
                continue
            try:
                if resolved_path.stat().st_size > max_file_bytes:
                    continue
            except OSError:
                continue
            yield resolved_path


def split_markdown_sections(text: str) -> list[tuple[str, str]]:
    """Return (heading, body) sections.

    Minimal deterministic parser; sufficient for hover fragments.
    """

    sections: list[tuple[str, list[str]]] = [("Document", [])]

    for line in text.splitlines():
        if line.startswith("#"):
            heading = line.lstrip("#").strip() or "Untitled"
            sections.append((heading, []))
        else:
            sections[-1][1].append(line)

    return [(heading, "\n".join(lines).strip()) for heading, lines in sections if "\n".join(lines).strip()]


def read_text_strict(path: Path) -> str:
    """Read UTF-8 text. UTF-8-SIG is accepted.

    No latin-1 fallback is used here because silent fallback can convert binary
    noise into false semantic text.
    """

    data = path.read_bytes()

    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return data.decode("utf-8")


class AnchorLoader:
    """Read-only, tier-first AnchorLoader."""

    def __init__(
        self,
        anchors_path: Path,
        *,
        follow_symlinks: bool = False,
        max_file_bytes: int = DEFAULT_MAX_FILE_BYTES,
    ) -> None:
        self.root = anchors_path.resolve(strict=True)
        self.follow_symlinks = follow_symlinks
        self.max_file_bytes = max_file_bytes
        self._items: list[ContextItem] = []
        self._anchor_hash = ""
        self.reload()

    def reload(self) -> None:
        """Reload all context items from disk.

        This is the only disk-reading operation beside construction.
        """

        items: list[ContextItem] = []
        digest = hashlib.sha256()

        for path in iter_text_files(
            self.root,
            follow_symlinks=self.follow_symlinks,
            max_file_bytes=self.max_file_bytes,
        ):
            rel = path.relative_to(self.root).as_posix()
            try:
                data = path.read_bytes()
                text = data.decode("utf-8-sig")
            except (OSError, UnicodeDecodeError):
                continue

            digest.update(rel.encode("utf-8"))
            digest.update(b"\0")
            digest.update(data)
            digest.update(b"\0")

            role = infer_role(path, self.root)
            modified_at = path.stat().st_mtime

            for heading, body in split_markdown_sections(text):
                items.append(
                    ContextItem(
                        source=rel,
                        heading=heading,
                        text=body,
                        role=role,
                        modified_at=modified_at,
                        importance=0.7 if role in {"canonical", "working_anchor"} else 0.5,
                        reliability=1.0 if role == "canonical" else 0.8 if role == "working_anchor" else 0.6,
                        continuity=0.8 if role in {"canonical", "working_anchor", "contract"} else 0.5,
                    )
                )

        self._items = sorted(items, key=lambda item: (canonical_tier(item), item.source, item.heading), reverse=True)
        self._anchor_hash = digest.hexdigest()

    def anchor_hash(self) -> str:
        """Return bytes/provenance fingerprint, not truth witness."""

        return self._anchor_hash

    def query(
        self,
        term: str,
        *,
        limit: int = 3,
        min_similarity: float = 0.05,
    ) -> list[ContextItem]:
        """Return top context items using tier-first ranking.

        No disk I/O occurs here.
        """

        ranked: list[RankedContextItem] = []

        for item in self._items:
            sim = semantic_similarity(term, item.text, item.heading)
            if sim < min_similarity:
                continue

            gravity = gravity_score(item, sim)

            ranked.append(
                RankedContextItem(
                    item=item,
                    semantic_similarity=sim,
                    gravity=gravity,
                    tier=canonical_tier(item),
                )
            )

        ranked.sort(key=ranking_key, reverse=True)
        return [entry.item for entry in ranked[: max(0, limit)]]


class AnchorHoverProvider:
    """Format AnchorLoader query results for LSP hover."""

    def __init__(self, loader: AnchorLoader, *, max_chars: int = 500) -> None:
        self.loader = loader
        self.max_chars = max_chars

    def hover(self, term: str) -> str | None:
        items = self.loader.query(term)
        if not items:
            return None

        blocks: list[str] = ["**VECTAETOS Sentinel**", ""]

        for index, item in enumerate(items, start=1):
            label = "Canonical reference" if canonical_tier(item) >= 40 else "Secondary context"
            excerpt = item.text.strip().replace("\n\n", "\n")
            if len(excerpt) > self.max_chars:
                excerpt = excerpt[: self.max_chars].rstrip() + "…"

            blocks.extend(
                [
                    f"### {label} {index}",
                    "",
                    f"`{term}`",
                    "",
                    excerpt,
                    "",
                    f"*z anchoru: `{item.source} → {item.heading}`*",
                    f"*tier: `{item.role}`; hover ≠ verdict; diagnostic ≠ truth*",
                    "",
                ]
            )

        return "\n".join(blocks).strip()


__all__ = [
    "AnchorLoader",
    "AnchorHoverProvider",
    "ContextItem",
    "RankedContextItem",
    "canonical_tier",
    "gravity_score",
    "ranking_key",
    "recency_signal",
    "semantic_similarity",
]
