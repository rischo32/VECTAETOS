#!/usr/bin/env python3
"""
Regression tests for VECTAETOS tiered AnchorLoader ranking.

These tests assert:
- recency cannot outrank canonical tier;
- gravity is only a retrieval signal inside the same tier;
- hover remains non-authoritative.
"""

from __future__ import annotations

import time

from anchor_loader_tiered import (
    ContextItem,
    RankedContextItem,
    canonical_tier,
    gravity_score,
    ranking_key,
)


def test_fresh_experiment_cannot_outrank_old_canonical() -> None:
    now = time.time()

    old_canonical = ContextItem(
        source="anchors/VECTAETOS_v1.0_Frozen_Ontological_Core.md",
        heading="ARTICLE IV — ENTROPIC HUMILITY",
        text="κ is an ontological boundary of representability, not a metric.",
        role="canonical",
        modified_at=now - 365 * 86400,
        importance=0.7,
        reliability=1.0,
        continuity=0.9,
    )

    fresh_experiment = ContextItem(
        source="experiments/kappa_notes.md",
        heading="Kappa threshold sketch",
        text="κ threshold experiment draft.",
        role="experiment",
        modified_at=now,
        importance=1.0,
        reliability=0.6,
        continuity=1.0,
    )

    canonical_ranked = RankedContextItem(
        item=old_canonical,
        semantic_similarity=0.30,
        gravity=gravity_score(old_canonical, 0.30, now=now),
        tier=canonical_tier(old_canonical),
    )

    experiment_ranked = RankedContextItem(
        item=fresh_experiment,
        semantic_similarity=1.00,
        gravity=gravity_score(fresh_experiment, 1.00, now=now),
        tier=canonical_tier(fresh_experiment),
    )

    assert ranking_key(canonical_ranked) > ranking_key(experiment_ranked)


def test_recency_only_orders_inside_same_tier() -> None:
    now = time.time()

    old_draft = ContextItem(
        source="drafts/a.md",
        heading="A",
        text="K(Φ) vocabulary.",
        role="draft",
        modified_at=now - 100 * 86400,
    )
    fresh_draft = ContextItem(
        source="drafts/b.md",
        heading="B",
        text="K(Φ) vocabulary.",
        role="draft",
        modified_at=now,
    )

    old_ranked = RankedContextItem(
        item=old_draft,
        semantic_similarity=0.8,
        gravity=gravity_score(old_draft, 0.8, now=now),
        tier=canonical_tier(old_draft),
    )
    fresh_ranked = RankedContextItem(
        item=fresh_draft,
        semantic_similarity=0.8,
        gravity=gravity_score(fresh_draft, 0.8, now=now),
        tier=canonical_tier(fresh_draft),
    )

    assert canonical_tier(old_draft) == canonical_tier(fresh_draft)
    assert ranking_key(fresh_ranked) > ranking_key(old_ranked)
